from django.contrib import admin
from .models import Contacto,Gatos,Postulacion
# Register your models here.

admin.site.register(Contacto)
admin.site.register(Gatos)
admin.site.register(Postulacion)